import React from 'react';
import { useSeats } from '../context/SeatContext';

const BookedList = () => {
  const { seats, cancelBooking } = useSeats();
  const booked = seats.filter((seat) => seat.status === 'booked');

  return (
    <div className="mt-4">
      <h2 className="text-lg font-semibold mb-2">Мої заброньовані місця:</h2>
      {booked.length === 0 && <p>Немає бронювань</p>}
      <ul className="space-y-1">
        {booked.map((seat) => (
          <li
            key={seat.id}
            className="flex justify-between items-center bg-gray-200 px-3 py-1 rounded"
          >
            {seat.id}
            <button
              onClick={() => cancelBooking(seat.id)}
              className="text-sm text-red-600 hover:underline"
            >
              Скасувати
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BookedList;