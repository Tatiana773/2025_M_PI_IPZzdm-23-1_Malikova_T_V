import React, { createContext, useContext, useState } from 'react';

const SeatContext = createContext();

const generateInitialSeats = () => {
  const seats = [];
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 8; col++) {
      seats.push({ id: `${row}-${col}`, status: 'free' });
    }
  }
  return seats;
};

export const SeatProvider = ({ children }) => {
  const [seats, setSeats] = useState(generateInitialSeats());

  const toggleSelect = (id) => {
    setSeats((prev) =>
      prev.map((seat) =>
        seat.id === id
          ? {
              ...seat,
              status:
                seat.status === 'free'
                  ? 'selected'
                  : seat.status === 'selected'
                  ? 'free'
                  : seat.status,
            }
          : seat
      )
    );
  };

  const confirmBooking = () => {
    setSeats((prev) =>
      prev.map((seat) =>
        seat.status === 'selected' ? { ...seat, status: 'booked' } : seat
      )
    );
  };

  const cancelBooking = (id) => {
    setSeats((prev) =>
      prev.map((seat) =>
        seat.id === id && seat.status === 'booked'
          ? { ...seat, status: 'free' }
          : seat
      )
    );
  };

  return (
    <SeatContext.Provider
      value={{ seats, toggleSelect, confirmBooking, cancelBooking }}
    >
      {children}
    </SeatContext.Provider>
  );
};

export const useSeats = () => useContext(SeatContext);