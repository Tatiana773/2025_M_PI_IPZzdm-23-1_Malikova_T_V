import { createSlice } from '@reduxjs/toolkit';

const generateInitialSeats = () => {
  const rows = 5;
  const cols = 8;
  const seats = [];
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      seats.push({ id: `${row}-${col}`, status: 'free' });
    }
  }
  return seats;
};

const seatsSlice = createSlice({
  name: 'seats',
  initialState: {
    list: generateInitialSeats(),
  },
  reducers: {
    toggleSelect: (state, action) => {
      const seat = state.list.find(s => s.id === action.payload);
      if (seat && seat.status === 'free') {
        seat.status = 'selected';
      } else if (seat && seat.status === 'selected') {
        seat.status = 'free';
      }
    },
    confirmBooking: (state) => {
      state.list.forEach(seat => {
        if (seat.status === 'selected') seat.status = 'booked';
      });
    },
    cancelBooking: (state, action) => {
      const seat = state.list.find(s => s.id === action.payload);
      if (seat && seat.status === 'booked') {
        seat.status = 'free';
      }
    },
  },
});

export const { toggleSelect, confirmBooking, cancelBooking } = seatsSlice.actions;
export default seatsSlice.reducer;
