import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { cancelBooking } from '../seatsSlice';

const BookedList = () => {
  const seats = useSelector((state) => state.seats.list.filter(s => s.status === 'booked'));
  const dispatch = useDispatch();

  return (
    <div className="mt-4">
      <h2 className="text-lg font-semibold mb-2">Мої заброньовані місця:</h2>
      {seats.length === 0 && <p>Немає бронювань</p>}
      <ul className="space-y-1">
        {seats.map(seat => (
          <li key={seat.id} className="flex justify-between items-center bg-gray-200 px-3 py-1 rounded">
            {seat.id}
            <button
              onClick={() => dispatch(cancelBooking(seat.id))}
              className="text-sm text-red-600 hover:underline"
            >
              Скасувати
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BookedList;
