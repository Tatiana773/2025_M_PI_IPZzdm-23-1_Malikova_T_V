import React from 'react';
import { useDispatch } from 'react-redux';
import { toggleSelect } from '../seatsSlice';

const Seat = ({ id, status }) => {
  const dispatch = useDispatch();

  const handleClick = () => {
    dispatch(toggleSelect(id));
  };

  const getColor = () => {
    if (status === 'booked') return 'bg-red-500';
    if (status === 'selected') return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div
      className={`w-10 h-10 m-1 cursor-pointer ${getColor()} text-white flex items-center justify-center rounded`}
      onClick={handleClick}
    >
      {id}
    </div>
  );
};

export default Seat;
