import React from 'react';
import { useDispatch } from 'react-redux';
import { confirmBooking } from '../seatsSlice';

const BookButton = () => {
  const dispatch = useDispatch();
  return (
    <button
      onClick={() => dispatch(confirmBooking())}
      className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-2"
    >
      Підтвердити бронювання
    </button>
  );
};

export default BookButton;
