import React from 'react';
import { useSelector } from 'react-redux';
import Seat from './Seat';

const SeatGrid = () => {
  const seats = useSelector((state) => state.seats.list);

  return (
    <div className="grid grid-cols-8 gap-2 p-4">
      {seats.map((seat) => (
        <Seat key={seat.id} id={seat.id} status={seat.status} />
      ))}
    </div>
  );
};

export default SeatGrid;
