import React from 'react';
import { useRecoilValue, useSetRecoilState } from 'recoil';
import { bookedSeatsSelector, seatListState } from '../store/seatAtoms';

const BookedList = () => {
  const bookedSeats = useRecoilValue(bookedSeatsSelector);
  const setSeats = useSetRecoilState(seatListState);

  const cancelBooking = (id) => {
    setSeats((prev) =>
      prev.map((seat) =>
        seat.id === id && seat.status === 'booked'
          ? { ...seat, status: 'free' }
          : seat
      )
    );
  };

  return (
    <div className="mt-4">
      <h2 className="text-lg font-semibold mb-2">Мої заброньовані місця:</h2>
      {bookedSeats.length === 0 && <p>Немає бронювань</p>}
      <ul className="space-y-1">
        {bookedSeats.map((seat) => (
          <li
            key={seat.id}
            className="flex justify-between items-center bg-gray-200 px-3 py-1 rounded"
          >
            {seat.id}
            <button
              onClick={() => cancelBooking(seat.id)}
              className="text-sm text-red-600 hover:underline"
            >
              Скасувати
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BookedList;