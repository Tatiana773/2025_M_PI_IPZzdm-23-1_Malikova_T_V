import React from 'react';
import { useRecoilState } from 'recoil';
import { seatListState } from '../store/seatAtoms';

const Seat = ({ id }) => {
  const [seats, setSeats] = useRecoilState(seatListState);
  const seat = seats.find((s) => s.id === id);

  const handleClick = () => {
    setSeats((prev) =>
      prev.map((s) =>
        s.id === id
          ? {
              ...s,
              status:
                s.status === 'free'
                  ? 'selected'
                  : s.status === 'selected'
                  ? 'free'
                  : s.status,
            }
          : s
      )
    );
  };

  const getColor = () => {
    if (seat.status === 'booked') return 'bg-red-500';
    if (seat.status === 'selected') return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div
      className={`w-10 h-10 m-1 cursor-pointer ${getColor()} text-white flex items-center justify-center rounded`}
      onClick={handleClick}
    >
      {seat.id}
    </div>
  );
};

export default Seat;