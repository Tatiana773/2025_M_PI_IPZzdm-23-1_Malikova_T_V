import { atom, selector } from 'recoil';

const generateInitialSeats = () => {
  const seats = [];
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 8; col++) {
      seats.push({ id: `${row}-${col}`, status: 'free' });
    }
  }
  return seats;
};

export const seatListState = atom({
  key: 'seatListState',
  default: generateInitialSeats(),
});

export const bookedSeatsSelector = selector({
  key: 'bookedSeatsSelector',
  get: ({ get }) => get(seatListState).filter((s) => s.status === 'booked'),
});
