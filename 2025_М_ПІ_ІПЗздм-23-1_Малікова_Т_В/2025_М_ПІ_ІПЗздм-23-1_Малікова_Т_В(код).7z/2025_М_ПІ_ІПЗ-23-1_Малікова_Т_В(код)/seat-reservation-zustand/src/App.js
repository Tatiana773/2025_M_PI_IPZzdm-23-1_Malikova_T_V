import React from 'react';
import SeatGrid from './components/SeatGrid';
import BookButton from './components/BookButton';
import BookedList from './components/BookedList';

const App = () => {
  return (
    <div className="min-h-screen p-6 bg-gray-100 text-center">
      <h1 className="text-3xl font-bold mb-4">Бронювання місць (Zustand)</h1>
      <SeatGrid />
      <BookButton />
      <BookedList />
    </div>
  );
};

export default App;