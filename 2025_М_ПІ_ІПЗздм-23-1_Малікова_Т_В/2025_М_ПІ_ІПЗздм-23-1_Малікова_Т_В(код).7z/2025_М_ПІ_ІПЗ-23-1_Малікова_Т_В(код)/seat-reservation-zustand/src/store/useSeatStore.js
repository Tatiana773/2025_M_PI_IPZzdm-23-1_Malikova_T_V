import create from 'zustand';

const generateInitialSeats = () => {
  const seats = [];
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 8; col++) {
      seats.push({ id: `${row}-${col}`, status: 'free' });
    }
  }
  return seats;
};

export const useSeatStore = create((set) => ({
  seats: generateInitialSeats(),
  toggleSelect: (id) =>
    set((state) => ({
      seats: state.seats.map((seat) =>
        seat.id === id
          ? {
              ...seat,
              status:
                seat.status === 'free'
                  ? 'selected'
                  : seat.status === 'selected'
                  ? 'free'
                  : seat.status,
            }
          : seat
      ),
    })),
  confirmBooking: () =>
    set((state) => ({
      seats: state.seats.map((seat) =>
        seat.status === 'selected' ? { ...seat, status: 'booked' } : seat
      ),
    })),
  cancelBooking: (id) =>
    set((state) => ({
      seats: state.seats.map((seat) =>
        seat.id === id && seat.status === 'booked'
          ? { ...seat, status: 'free' }
          : seat
      ),
    })),
}));